<?php
include 'Includes/login_session.php';
include ('Includes/config.php');
$email = $_POST['email'];
$pass = $_POST['password'];
$sql = "SELECT * FROM user_dtl WHERE email = '{$email}' AND password = '{$pass}'";
$result = mysqli_query($conn,$sql) or die("Query Failed");
if(mysqli_num_rows($result) > 0){
	$row = mysqli_fetch_assoc($result);
	if ($row['status'] == 'Active') {
		include 'php_mailer/functions.php';
		sendMail($row['email'],"Login");
	}else{
		$_SESSION["msg"] = "Your Id is Inactive.";
	}
	} else{
		session_start();
		$_SESSION["msg"] = "Id or Password Is Wrong.";
	}
 ?>