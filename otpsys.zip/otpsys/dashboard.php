<?php 
session_start();
include 'Includes/set_session.php';
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
 	<title>Welcome - Dashboard</title>
 </head>
 <body>
 	<div style="margin-top: auto;">
 		<center>
 			<h1>Welcome - <?php echo $_SESSION["name"] ?></h1><br>
 			<h2>Email - <?php echo $_SESSION["email"] ?></h2><br>
 			<h2>Status - <?php echo $_SESSION["status"] ?></h2><br><br>
 			<h3><a href="Includes/logout.php">Logout</a></h3>
 		</center>
 	</div>
 </body>
 </html>