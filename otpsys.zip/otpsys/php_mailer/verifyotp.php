<?php 
session_start();
$otp = $_POST['otpvalue'];
$email = $_POST['email'];
include "../Includes/config.php";

$query = "SELECT * FROM otp_dtl WHERE email = '$email'";
$result = mysqli_query($conn,$query);
if(mysqli_num_rows($result) > 0){
	while ($row = mysqli_fetch_assoc($result)) {
		$op = $row['otp'];
		$attempt = $row['attempt'];
		if ($attempt>=1) {
			if ($otp == $op){
				// echo "<label>Your otp Verified successfully</label>";
				$sql = "SELECT * FROM user_dtl WHERE email = '{$email}'";
				$result = mysqli_query($conn,$sql) or die("Query Failed");
				$row = mysqli_fetch_assoc($result);
				$_SESSION['email'] = $row['email'];
				$_SESSION['name'] = $row['name'];
				$_SESSION['status'] = $row['status'];
				echo "yes";
				$delsql = "DELETE FROM otp_dtl WHERE email = '$email'";
				mysqli_query($conn,$delsql);

			} elseif  ($otp == ''){
				echo "onull";
			} else{
				$query = "UPDATE otp_dtl SET attempt = attempt-1 WHERE email = '$email'";
				mysqli_query($conn,$query);
				if(($attempt-1)==0){
					$query = "UPDATE user_dtl SET status ='Inactive', inactive_reason='Wrong OTP' WHERE email = '$email'";
					mysqli_query($conn,$query);
					$delsql = "DELETE FROM otp_dtl WHERE email = '$email'";
					mysqli_query($conn,$delsql);
					$_SESSION["msg"] = "Your User Id is Blocked, Please Contact Technical Team.";
					echo "inactive";
				}else{
					echo ($attempt-1);
				}
				
			}
		} 
	}
} else{
	echo "Something went Wrong";							
	}

?>