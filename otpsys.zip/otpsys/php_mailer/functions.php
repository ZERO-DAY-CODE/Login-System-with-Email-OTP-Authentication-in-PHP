<?php
include('smtp/PHPMailerAutoload.php');
	function smtp_mailer($to,$subject, $msg){
		$mail = new PHPMailer(); 
		$mail->IsSMTP(); 
		$mail->SMTPAuth = true; 
		$mail->SMTPSecure = 'tls'; 
		$mail->Host = "smtp.gmail.com";
		$mail->Port = 587; 
		$mail->IsHTML(true);
		$mail->CharSet = 'UTF-8';
			//$mail->SMTPDebug = 2; 
		$mail->Username = "akash.prajapatiak450@gmail.com";
		$mail->Password = "ipskhgpfwmghaxxl";
		$mail->SetFrom("akash.prajapatiak450@gmail.com");
		$mail->Subject = $subject;
		$mail->Body =$msg;
		$mail->AddAddress($to);
		$mail->SMTPOptions=array('ssl'=>array(
			'verify_peer'=>false,
			'verify_peer_name'=>false,
			'allow_self_signed'=>false
		));
		if(!$mail->Send()){
			return $mail->ErrorInfo;
		}else{
			return 'Sent';
		}
	}


	function sendMail($email,$otptype){
	include "Includes/config.php";
	if ($email != ''){
		$otp = rand(000001,999999);
	
		$send = smtp_mailer($email,'You have recived a Login OTP.','Your Login OTP is '.$otp);
		$sql = "SELECT * FROM otp_dtl WHERE email = '{$email}'";
		$result = mysqli_query($conn,$sql) or die("Query Failed");
		if(mysqli_num_rows($result) > 0){
			$row = mysqli_fetch_assoc($result);
			$attempt = $row['attempt'];
			$query = "UPDATE otp_dtl SET otp = '$otp', c_time = now(), attempt='{$attempt}' WHERE email = '$email'";
			$res = mysqli_query($conn,$query);
			if($res){
				echo "yes";
			} else{
				echo "Something is wrong";
			}

		} else{
			if($send == 'Sent'){
		
			$sql = "INSERT INTO otp_dtl(email , otp, c_time, attempt) VALUES('{$email}','{$otp}', now(),'5')";
			$res = mysqli_query($conn,$sql);
		
			if($res){
				echo "yes";
				} else{
					echo "Something is wrong";
				}
			} else{
				echo "OTP Sent Failed.";
				}
		}
		
	}else{
		echo "Email is null";
		}
	}

 ?>