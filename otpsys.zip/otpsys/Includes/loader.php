<style>
	.load_img{
		height: 100px;
		width: auto;
		
	}
	.load_text{
		
		font-size: 26px;
		font-weight: 600;
		position: ;
	}
	.loader_div{
		
		z-index: 11;
		background: #fff;
		top: 50%;
		left: 50%;
		position: fixed;
		border: 1px solid red;
		padding: 100%;
		transform: translate(-50%,-50%);
		opacity: 0.6;
		display: none;
		
			}
</style>
<div class="loader_div" style="display: none;">
	<img class="load_img" src="Includes/loading.gif"><br>
	<span class="load_text">Validating</span>
	
</div>
