<?php 
include 'Includes/login_session.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css" />
	<link href="css/emp.css" rel="stylesheet">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://code.jquery.com/jquery-1.7.1.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.5/dist/sweetalert2.all.min.js"></script>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.5/dist/sweetalert2.min.css">
	<title> Login Page </title>
</head>
<body>
	<?php include('Includes/loader.php'); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-7 mx-auto mt-4">
				<div class="card-box mx-auto mt-1">
					<div class="mx-auto mt-4" style="text-align:center;"><i class="fa fa-user-o mx-auto" style="font-size:65px;"></i>
						<div class="card-box-header pt-4" style="text-align: center; font-weight: 550;">Login With OTP Authetication
						</div>
						<div class="text-danger text-bold pt-2"><b><?php

						if(isset($_SESSION['msg'])){
							echo $_SESSION['msg'];
							unset ($_SESSION['msg']);
						} ?></b>
					</div>
					<form>

						<div class="input-group pt-5 w-75 mx-auto">
							<span class="input-group-prepend"style="">
								<div class="input-group-text bg-transparent border-right-0" style=""><i class="fa fa-envelope" style="border-radius:0; font-size:24px;"></i>
								</div>
							</span>
							<input type="email" id="email" class="form-control p-3 border-left-0 border " name="email" placeholder="Enter Email *" style=""required autocomplete="off">
						</div>
						<div class="input-group pt-4 w-75 mx-auto">
							<span class="input-group-prepend" style="">
								<div class="input-group-text bg-transparent border-right-0"><i class="fa fa-lock" style="font-size: 24px;"></i>
								</div>
							</span>
							<input type="password" id="password" name="password" class="form-control p-3 border-left-0 border" placeholder="Enter Password *" style="" maxlength="15" minlength="7" required>
							<span toggle="#password-field" id="eye" class="bi bi-eye-slash toggle-password" style="" onclick="myFunction()"></span>
						</div>
						<p class="pt-1 mx-4 mt-3 " style="float: right; color:red; font-size: 19px; font-weight:500;"><a href="#" style="text-decoration: none;">Forgot Password</a></p>

						<div class="input-group pt-5" style="padding-bottom: 10%;">
							<input type="button" style="" class=" mx-auto shadow" value="Login" name="login" autocomplete="off" id="login">
						</div>
					</form>
					
				</div>
				
			</div>
		</div>
	</div>
</body>
</html>
<script>
	function myFunction() {
		var x = document.getElementById("password");
		var y = document.getElementById("eye");

		if (x.type === "password") {
			x.type = "text";
			y.setAttribute("class", "bi-eye");
		} else {
			x.type = "password";
			y.setAttribute("class", "bi-eye-slash");
		}
	}
	const inp = document.getElementById("email");
	inp.addEventListener("input", ()=>{
		inp.value = inp.value.toLowerCase();
	})

	const Toast = Swal.mixin({
		toast: true,
		position: "top-end",
		showConfirmButton: false,
		timer: 3000,
		timerProgressBar: true,
		didOpen: (toast) => {
			toast.onmouseenter = Swal.stopTimer;
			toast.onmouseleave = Swal.resumeTimer;
		}
	});
	$(document).on('click', '.SwalBtn1', function() {
        //Some code 1
		console.log('Button 1');
		swal.clickConfirm();
	});

	$(document).ready(function(){
		$('#login').click(function(){
			$(".loader_div").css("display", "block");
			var email =$('#email').val();
			var password =$('#password').val();
			$.ajax({
				url: 'auth.php',
				type:'POST',
				data: { email : email, password : password},
				success: function(response){
					$(".loader_div").css("display", "none");
					if (response == "yes") {
						(async () => {
							const {value:otpvalue} = await Swal.fire({
								allowOutsideClick: false,
								title: 'Verify OTP.',
								
								input: "text",
								inputLabel: "Otp Sent on your Registered E-mail.",
								inputPlaceholder: "Enter OTP",
								inputAttributes: {
									maxlength: "6",
									minlength: "6",
								},
								showCloseButton: true,
								showCancelButton: true,
								cancelButtonText: "Resend OTP",
								confirmButtonText:"Verify",
								
								inputValidator: (otpvalue) => {
									return new Promise((resolve) => {
										$.ajax({
											url: "php_mailer/verifyotp.php",
											type: "POST",
											data: {otpvalue : otpvalue, email : email},
											success: function(response){
												if (response=="yes") {
													Swal.fire({
														title: "Login Successful",
														icon: "success"
													});
													setTimeout(function(){
														window.location = ("dashboard.php");
													},1900)
												} else if (response == 'onull'){
													resolve("Please Enter OTP");
												}else if (response == 'inactive'){
													location.reload();
												} else{
													resolve("Your OTP is wrong, Only "+response+" Attempt left");
												}
											}
										})
									});
								}
							})
						})()
					} else {
						location.reload();
					}
				}		
			});
		});
	});
</script>





